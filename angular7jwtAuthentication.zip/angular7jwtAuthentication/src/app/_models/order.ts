
export class Order {
    orderId:number;
    orderDate:Date;
    orderAmount:number
    customerId :number;
}

