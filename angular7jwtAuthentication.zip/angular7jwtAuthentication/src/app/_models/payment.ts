export class payment{
     paymentId:number;
      amount:number;
      paymentDate:Date;
       cardDigit:number;
       description:string;
      orderId:number;
       stripeSettingsId :number;
    customerId :number;
}