export class Category {
    categoryId:number;
    categoryName:string;
    categoryDescription:string;
}
