export class admin{
    adminId:number;
    firstName:string;
    lastName:string;
    password:string;
    email:string;
    address:string;
    country:string;
    state:string;
    zipCode:number;
    phoneNumber:number;
    alternatePhoneNumber:number;
    gender:string;
}