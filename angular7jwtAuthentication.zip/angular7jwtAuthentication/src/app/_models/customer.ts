export class Customer {
    customerId:number;
    customerFirstName:string;
    customerLastName:string;
    userName:string;
    email:string;
    address:string;
    country:string;
    state:string;
    zipCode:number;
    phoneNumber:number;
    gender:string;
    password:string;
}
