import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AuthGuard } from './_guards';
import { AboutComponent } from './about/about.component';
import { BrandComponent } from './brands/brand/brand.component';
import { BrandAddComponent } from './brands/brand-add/brand-add.component';
import { BrandEditComponent } from './brands/brand-edit/brand-edit.component';
import { BrandDetailsComponent } from './brands/brand-details/brand-detail.component';
import { CategoryComponent } from './categories/category/category.component';
import { CategoryAddComponent } from './categories/category-add/category-add.component';
import { CategoryEditComponent } from './categories/category-edit/category-edit.component';
import { CategoryDetailsComponent } from './categories/category-details/category-detail.component';
import { VendorComponent } from './vendors/vendor/vendor.component';
import { VendorAddComponent } from './vendors/vendor-add/vendor-add.component';
import { VendorEditComponent } from './vendors/vendor-edit/vendor-edit.component';
import { VendorDetailsComponent } from './vendors/vendor-details/vendor-detail.component';
import { ProductComponent } from './products/product/product.component';
import { ProductAddComponent } from './products/product-add/product-add.component';
import { ProductEditComponent } from './products/product-edit/product-edit.component';
import { ProductDetailsComponent } from './products/product-details/product-detail.component';
import { FeedbackComponent } from './feedbacks/feedback/feedback.component';
import { FeedbackDetailsComponent } from './feedbacks/feedback-details/feedback-details.component';
import { OrderComponent } from './orders/order/order.component';
import { OrderAddComponent } from './orders/order-add/order-add.component';
import { OrderEditComponent } from './orders/order-edit/order-edit.component';
import { OrderDetailsComponent } from './orders/order-details/order-details.component';
import { CustomerComponent } from './customers/customer/customer.component';
import { CustomerAddComponent } from './customers/customer-add/customer-add.component';
import { CustomerEditComponent } from './customers/customer-edit/customer-edit.component';
import { CustomerDetailsComponent } from './customers/customer-details/customer-details.component';
import { ManagerComponet } from './managers/manager/manager.component';
import { ManagerAddComponent } from './managers/manager-add/manager-add.component';
import { managerEditComponent } from './managers/manager-edit/manager-edit.component';
import { managerDetailsComponent } from './managers/manager-details/manager-details.component';
import { paymentDetailsComponent } from './payments/payment-details/payment-details.component';
import { paymentComponent } from './payments/payment/payment.component';


const appRoutes: Routes = [
    {
        path: '',
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
     {
         path:'about',component:AboutComponent,
         canActivate:[AuthGuard]
     },

     {path:'brand',component:BrandComponent,canActivate:[AuthGuard]},
    {path:'brand-add',component:BrandAddComponent,canActivate:[AuthGuard]},
    {path:'brand-edit/:id',component:BrandEditComponent,canActivate:[AuthGuard]},
    {path:'brand-details/:id',component:BrandDetailsComponent,canActivate:[AuthGuard]},
    {path:'manager',component:ManagerComponet,canActivate:[AuthGuard]},
    {path:'manager-add',component:ManagerAddComponent,canActivate:[AuthGuard]},
    {path:'manager-edit/:id',component:managerEditComponent,canActivate:[AuthGuard]},
    {path:'manager-details/:id',component:managerDetailsComponent,canActivate:[AuthGuard]},
    {path:'category',component:CategoryComponent,canActivate:[AuthGuard]},
    {path:'category-add',component:CategoryAddComponent,canActivate:[AuthGuard]},
    {path:'category-edit/:id',component:CategoryEditComponent,canActivate:[AuthGuard]},
    {path:'category-details/:id',component:CategoryDetailsComponent,canActivate:[AuthGuard]},
    {path:'payment',component:paymentComponent,canActivate:[AuthGuard]},
    {path:'payment-details/:id',component:paymentDetailsComponent,canActivate:[AuthGuard]},
    {path:'vendor',component:VendorComponent,canActivate:[AuthGuard]},
    {path:'vendor-add',component:VendorAddComponent,canActivate:[AuthGuard]},
    {path:'vendor-edit/:id',component:VendorEditComponent,canActivate:[AuthGuard]},
    {path:'vendor-details/:id',component:VendorDetailsComponent,canActivate:[AuthGuard]},
    {path:'product',component:ProductComponent,canActivate:[AuthGuard]},
    {path:'product-add',component:ProductAddComponent,canActivate:[AuthGuard]},
    {path:'product-edit/:id',component:ProductEditComponent,canActivate:[AuthGuard]},
    {path:'product-details/:id',component:ProductDetailsComponent,canActivate:[AuthGuard]},
    {path:'feedback',component:FeedbackComponent,canActivate:[AuthGuard]},
    {path:'feedback-details/:id',component:FeedbackDetailsComponent,canActivate:[AuthGuard]},
    {path:'order',component:OrderComponent,canActivate:[AuthGuard]},
    {path:'order-add',component:OrderAddComponent,canActivate:[AuthGuard]},
    {path:'order-edit/:id',component:OrderEditComponent,canActivate:[AuthGuard]},
    {path:'order-details/:id',component:OrderDetailsComponent,canActivate:[AuthGuard]},
    {path:'customer',component:CustomerComponent,canActivate:[AuthGuard]},
    {path:'customer-add',component:CustomerAddComponent,canActivate:[AuthGuard]},
    {path:'customer-edit/:id',component:CustomerEditComponent,canActivate:[AuthGuard]},
    {path:'customer-details/:id',component:CustomerDetailsComponent,canActivate:[AuthGuard]},
  
    {
        path: 'login',
        component: LoginComponent
    },

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);