import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/_services/product.service';
import { Product } from 'src/app/_models/product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers:[ProductService]
})
export class ProductComponent implements OnInit {

  products:Product[];
  constructor(private _products: ProductService) { }

  ngOnInit() {
    this.getAllProducts()
  }
  getAllProducts() {
    this._products.getProducts().subscribe(result => {
      this.products = result;
      console.log(this.products);
    })
  }
  deleteExistingproduct(id: number) {
    this._products.deleteProducts(id).subscribe(result => {
      console.log("Product Deleted Successfully");
      this.getAllProducts();

    })
  }

}
