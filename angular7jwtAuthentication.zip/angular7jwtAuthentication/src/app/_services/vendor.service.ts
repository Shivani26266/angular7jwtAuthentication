import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Vendor } from '../_models/vendor';
const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class VendorService {

  constructor(private _Http: HttpClient) { }
  getVendors():Observable<Vendor[]>{
    return this._Http.get<Vendor[]>("http://localhost:54638/api/vendor");
  }
  getVendorsById(id:number):Observable<Vendor>{
    return this._Http.get<Vendor>("http://localhost:54638/api/vendor/"+id);
  }
  deleteVendors(id:number):Observable<Vendor>{
   return this._Http.delete<Vendor>("http://localhost:54638/api/vendor/"+id);
  }
  addNewVendor(vendor:Vendor):Observable<Vendor>{
    return this._Http.post<Vendor>("http://localhost:54638/api/vendor/",vendor,httpOptions);
   }
   editVendor(id:number, vendor:Vendor):Observable<Vendor>{
    return this._Http.put<Vendor>("http://localhost:54638/api/vendor/"+id,vendor,httpOptions);
   }
}
