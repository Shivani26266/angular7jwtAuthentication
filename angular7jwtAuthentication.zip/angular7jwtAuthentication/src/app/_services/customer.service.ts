import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../_models/customer';

const httpOptions ={
  headers: new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class CustomerService {

  constructor(private _Http: HttpClient) { }
  getCustomer():Observable<Customer[]>{
    return this._Http.get<Customer[]>("http://localhost:54638/api/customer");
  }
  getCustomerById(id:number):Observable<Customer>{
    return this._Http.get<Customer>("http://localhost:54638/api/customer/"+id);
  }
  deleteCustomer(id:number):Observable<Customer>{
   return this._Http.delete<Customer>("http://localhost:54638/api/customer/"+id);
  }
   editCustomer(id:number, customer:Customer):Observable<Customer>{
    return this._Http.put<Customer>("http://localhost:54638/api/customer/"+id,customer,httpOptions);
   }
}
