import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/_services/customer.service';
import { Customer } from 'src/app/_models/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
  providers:[CustomerService]
})
export class CustomerComponent implements OnInit {

  customer:Customer[];
  constructor(private _customer: CustomerService) { }

  ngOnInit() {
    this.getAllCustomer()
  }
  getAllCustomer() {
    this._customer.getCustomer().subscribe(result => {
      this.customer = result;
      console.log(this.customer);
    })
  }
  deleteExistingCustomer(id: number) {
    this._customer.deleteCustomer(id).subscribe(result => {
      console.log("Customer Deleted Successfully");
      this.getAllCustomer() ;

    })
  }

}
