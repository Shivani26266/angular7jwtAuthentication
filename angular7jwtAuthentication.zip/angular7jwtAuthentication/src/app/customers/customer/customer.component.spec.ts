import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CustomerComponent} from './customer.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { CustomerService } from 'src/app/_services/customer.service';
describe('Testing Customer Component', () => {
    let component: CustomerComponent;
    let fixture: ComponentFixture<CustomerComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerComponent],
            imports: [RouterTestingModule,HttpClientModule],
            providers: [CustomerService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(CustomerComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves all Customer',async(inject([CustomerService],(customerService)=>{
        customerService.getCustomer().subscribe(result=>{
            expect(result.length).toEqual(2);
        })  
   })));
//     it('Delete specific Customer',async(inject([CustomerService],(customerServie)=>{
//         customerServie.deleteCustomer(6).subscribe(result=>{
//             console.log('Customer deleted successfully');
            
//         })  
//    })));
})
