import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/_services/customer.service';
import { Customer } from 'src/app/_models/customer';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css'],
  providers:[CustomerService]
})
export class CustomerEditComponent implements OnInit {

  id: number;
  customer:Customer=new Customer();
  catForm:FormGroup;
  constructor(private _cr: CustomerService, private route: ActivatedRoute,private router:Router,private fb:FormBuilder) {
    this.editForm();
   }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._cr.getCustomerById(this.id).subscribe(result => {
        this.customer = result;
      })
    })
  }
  editExistingCustomer() {
    this._cr.editCustomer(this.id, this.customer).subscribe(result => {
      console.log('Updated Successfully');
      this.router.navigate(['/customer'])
    });
  }
  editForm(){
    this.catForm=this.fb.group({
      customerFirstName:['',Validators.required],
      email:['',Validators.required],
      phoneNumber:['',Validators.required],
      gender:['',Validators.required],
      password:['',Validators.required],
      customerLastName:['',Validators.required],
      userName:['',Validators.required],
      address:['',Validators.required],
      country:['',Validators.required],
      state:['',Validators.required],
      zipCode:['',Validators.required]

    })
  }

}
