import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/_services/order.service';
import { Order } from 'src/app/_models/order';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from 'src/app/_services/customer.service';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css'],
  providers:[OrderService,CustomerService]
})
export class OrderDetailsComponent implements OnInit {

  id: number;
  cname:string;
  order:Order=new Order();
  constructor(private route: ActivatedRoute, private cat: OrderService,private router:Router,private cus:CustomerService) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this.cat.getOrderById(this.id).subscribe(result => {
        this.order = result;
        this.cus.getCustomerById(result.customerId).subscribe(res=>{
          this.cname=res.customerFirstName + " "+res.customerLastName;
        })
        console.log(result);
      })
    });
  }
  deleteExistingOrder(id: number) {
    this.cat.deleteOrder(id).subscribe(result => {
      console.log("Order Deleted Successfully");
      this.router.navigate(['/order']);
    })
  }

}
