import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{OrderDetailsComponent} from './order-details.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { OrderService } from 'src/app/_services/order.service';
describe('Testing Order-Details Component', () => {
    let component: OrderDetailsComponent;
    let fixture: ComponentFixture<OrderDetailsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [OrderDetailsComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [OrderService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(OrderDetailsComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves Order by ID',async(inject([OrderService],(orderServie)=>{
        orderServie.getOrderById(7).subscribe(result=>{           
            console.log("Order with ID 7");
            
       })  
   })));
})
