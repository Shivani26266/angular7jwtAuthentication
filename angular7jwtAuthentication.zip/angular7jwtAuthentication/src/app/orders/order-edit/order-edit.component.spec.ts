import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{OrderEditComponent} from './order-edit.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Order } from 'src/app/_models/order';
import { OrderService } from 'src/app/_services/order.service';
describe('Testing Order-Edit Component', () => {
    let component: OrderEditComponent;
    let fixture: ComponentFixture<OrderEditComponent>;
    let order:Order =new Order()
    {
    order.customerId=2,
    order.orderAmount=4000,
    order.orderId=7
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [OrderEditComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [OrderService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(OrderEditComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Edit Brand',async(inject([OrderService],(orderServie)=>{
        orderServie.editOrder(7,order).subscribe(result=>{         
           console.log("Order Updated successfully");          
         })  
    })));
})
