import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from 'src/app/_services/category.service';
import { Category } from 'src/app/_models/category';

@Component({
  selector: 'app-category-edit',
  templateUrl: './category-edit.component.html',
  styleUrls: ['./category-edit.component.css'],
  providers: [CategoryService]
})
export class CategoryEditComponent implements OnInit {

  id: number;
  category: Category = new Category();
  catEditForm:FormGroup;
  constructor(private _br: CategoryService, private route: ActivatedRoute,private router:Router,private fb:FormBuilder) {
    this.editForm();
   }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._br.getCategoriesById(this.id).subscribe(result => {
        this.category = result;
      })
    })
  }
  editExistingCategory() {
    this._br.editCategory(this.id, this.category).subscribe(result => {
      console.log('Updated Successfully');
      this.router.navigate(['/category'])
    });
  }
  editForm(){
    this.catEditForm=this.fb.group({
      categoryName:['',Validators.required],
      categoryDescription:['',Validators.required]
    })
  }
}