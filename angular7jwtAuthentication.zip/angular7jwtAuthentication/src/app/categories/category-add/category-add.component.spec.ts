import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{CategoryAddComponent} from './category-add.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { Category } from 'src/app/_models/category';
import { CategoryService } from 'src/app/_services/category.service';

describe('Testing Category-Add',()=>{
    let component:CategoryAddComponent;
    let fixture:ComponentFixture<CategoryAddComponent>;
    let cat:Category =new Category()
    {
        cat.categoryName="Goggles",
        cat.categoryDescription="Goggle's Description"
    };  
    beforeEach(async()=>{
       TestBed.configureTestingModule({
           declarations:[CategoryAddComponent],
           imports:[RouterTestingModule,HttpClientModule,ReactiveFormsModule],
           providers:[CategoryService]
       }).compileComponents();
    });
    beforeEach(()=>{
        fixture=TestBed.createComponent(CategoryAddComponent);
        component=fixture.componentInstance;
    });
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    //  it('Add New Category',async(inject([CategoryService],(categoryServie)=>{
    //      categoryServie.addNewCategory(cat).subscribe(result=>{         
    //         console.log("Category Added successfully");          
    //       })  
    // })));
})