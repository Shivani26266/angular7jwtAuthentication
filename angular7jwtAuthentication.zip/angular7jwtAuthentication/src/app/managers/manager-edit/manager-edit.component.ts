import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ManagerService } from 'src/app/_services/manager.services';
import { manager } from 'src/app/_models/manager';

@Component({
  selector: 'app-manager-edit',
  templateUrl: './manager-edit.component.html',
  styleUrls: ['./manager-edit.component.css'],
  providers: [ManagerService]
})
export class managerEditComponent implements OnInit {

  id: number;
  brand: manager = new manager();
  brandForm:FormGroup;
  constructor(private _br: ManagerService, private route: ActivatedRoute,private router:Router,private fb:FormBuilder) {
    this.editForm();
   }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._br.getManagerById(this.id).subscribe(result => {
        this.brand = result;
      })
    })
  }
  editExistingBrand() {
    this._br.editManager(this.id, this.brand).subscribe(result => {
      console.log('Updated Successfully');
      this.router.navigate(['/manager'])
    });
  }
  editForm(){
    this.brandForm=this.fb.group({
      managerFirstName:['',Validators.required],
      managerLastName:['',Validators.required],
      managerPassword:['',Validators.required],
      managerEmail:['',Validators.required],
      managerAddress:['',Validators.required],
      managerCountry:['',Validators.required],
      managerState:['',Validators.required],
      managerZipCode:['',Validators.required],
      managerPhoneNumber:['',Validators.required]
    })
  }
}


