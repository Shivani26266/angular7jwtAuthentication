import { Component, OnInit } from '@angular/core';
import { manager } from 'src/app/_models/manager';
import { ManagerService } from 'src/app/_services/manager.services';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css'],
  providers: [ManagerService]
})
export class ManagerComponet implements OnInit {

  brands: manager[];
  constructor(private _brands: ManagerService) { }

  ngOnInit() {
    this.getAllManagers()
  }
  getAllManagers() {
    this._brands.getManager().subscribe(result => {
      this.brands = result;
      console.log(this.brands);
    })
  }
  deleteExistingManager(id: number) {
    this._brands.deleteManager(id).subscribe(result => {
      console.log("Manager Deleted Successfully");
      this.getAllManagers();

    })
  }
}
