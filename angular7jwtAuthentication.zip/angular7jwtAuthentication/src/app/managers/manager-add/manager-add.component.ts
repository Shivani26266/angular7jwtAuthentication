import { Component, OnInit } from '@angular/core';
import { ManagerService } from 'src/app/_services/manager.services';
import { manager } from 'src/app/_models/manager';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager-add',
  templateUrl: './manager-add.component.html',
  styleUrls: ['./manager-add.component.css'],
  providers:[ManagerService]
})
export class ManagerAddComponent implements OnInit {

  brand:manager=new manager();
  brandForm: FormGroup;
  constructor(private _br:ManagerService,private router:Router,private fb:FormBuilder) { 
    this.createForm();
  }


  ngOnInit() {
  }
  addNewBrand(){
    this._br.addNewManager(this.brand).subscribe(result =>{
      console.log(result);
      console.log('Manager Added Successfully.');
      this.router.navigate(['/manager']);
    });
  }
   
  createForm(){
    this.brandForm=this.fb.group({
      managerFirstName:['',Validators.required],
      managerLastName:['',Validators.required],
      managerPassword:['',Validators.required],
      managerEmail:['',Validators.required],
      managerAddress:['',Validators.required],
      managerCountry:['',Validators.required],
      managerState:['',Validators.required],
      managerZipCode:['',Validators.required],
      managerPhoneNumber:['',Validators.required]
    })
  }
}




