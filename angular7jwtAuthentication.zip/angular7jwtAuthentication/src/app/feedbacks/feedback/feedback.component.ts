import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/_services/feedback.service';
import { Feedback } from 'src/app/_models/feedback';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css'],
  providers:[FeedbackService]
})
export class FeedbackComponent implements OnInit {
  feedback:Feedback[];
  constructor(private _feedback: FeedbackService) { }

  ngOnInit() {
    this.getAllFeedback();
  }
  getAllFeedback() {
    this._feedback.getFeedBack().subscribe(result => {
      this.feedback = result;
      console.log(this.feedback);
    })
  }
}
