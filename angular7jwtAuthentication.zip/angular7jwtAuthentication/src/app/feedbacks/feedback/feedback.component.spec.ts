import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{FeedbackComponent} from './feedback.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { FeedbackService } from 'src/app/_services/feedback.service';
describe('Testing FeedBack Component', () => {
    let component: FeedbackComponent;
    let fixture: ComponentFixture<FeedbackComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FeedbackComponent],
            imports: [RouterTestingModule,HttpClientModule],
            providers: [FeedbackService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(FeedbackComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves all Feedbacks',async(inject([FeedbackService],(feedbackService)=>{
        feedbackService.getFeedBack().subscribe(result=>{
            expect(result.length).toEqual(3);
            console.log("Retrieves all feedback");
            
        })  
   })));
})
