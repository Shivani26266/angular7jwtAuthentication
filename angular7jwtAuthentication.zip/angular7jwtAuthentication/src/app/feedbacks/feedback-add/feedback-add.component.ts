import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-add',
  templateUrl: './feedback-add.component.html',
  styleUrls: ['./feedback-add.component.css']
})
export class FeedbackAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
