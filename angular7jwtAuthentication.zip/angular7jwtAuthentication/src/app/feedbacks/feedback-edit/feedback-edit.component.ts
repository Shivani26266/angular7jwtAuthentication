import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-edit',
  templateUrl: './feedback-edit.component.html',
  styleUrls: ['./feedback-edit.component.css']
})
export class FeedbackEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
