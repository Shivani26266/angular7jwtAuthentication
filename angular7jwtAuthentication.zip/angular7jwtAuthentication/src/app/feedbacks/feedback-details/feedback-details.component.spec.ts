import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{FeedbackDetailsComponent} from './feedback-details.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FeedbackService } from 'src/app/_services/feedback.service';
describe('Testing FeedBack-Deatils Component', () => {
    let component: FeedbackDetailsComponent;
    let fixture: ComponentFixture<FeedbackDetailsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FeedbackDetailsComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [FeedbackService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(FeedbackDetailsComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    it('Retrieves Brand by ID',async(inject([FeedbackService],(feedbackServie)=>{
        feedbackServie.getFeedBackById(3).subscribe(result=>{           
            console.log("Feedback with ID 3");
            
       })  
   })));
})
