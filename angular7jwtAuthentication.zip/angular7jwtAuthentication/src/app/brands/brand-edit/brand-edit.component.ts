import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BrandService } from 'src/app/_services/brand.service';
import { Brand } from 'src/app/_models/brand';

@Component({
  selector: 'app-brand-edit',
  templateUrl: './brand-edit.component.html',
  styleUrls: ['./brand-edit.component.css'],
  providers: [BrandService]
})
export class BrandEditComponent implements OnInit {

  id: number;
  brand: Brand = new Brand();
  brandEditForm:FormGroup;
  constructor(private _br: BrandService, private route: ActivatedRoute,private router:Router,private fb:FormBuilder) {
    this.editForm();
   }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.id = +param['id'];
      this._br.getBrandsById(this.id).subscribe(result => {
        this.brand = result;
      })
    })
  }
  editExistingBrand() {
    this._br.editBrand(this.id, this.brand).subscribe(result => {
      console.log('Updated Successfully');
      this.router.navigate(['/brand'])
    });
  }
  editForm(){
    this.brandEditForm=this.fb.group({
      brandName:['',Validators.required],
      brandDescription:['',Validators.required]
    })
  }
}


