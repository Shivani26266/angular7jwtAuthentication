import{async,ComponentFixture,TestBed, inject} from '@angular/core/testing';
import{BrandAddComponent} from './brand-add.component';
import {RouterTestingModule} from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BrandService } from 'src/app/_services/brand.service';
import { Brand } from 'src/app/_models/brand';
describe('Testing Brand-Add Component', () => {
    let component: BrandAddComponent;
    let fixture: ComponentFixture<BrandAddComponent>;
    let brand:Brand =new Brand()
    {
        brand.brandName="Nike";
        brand.brandDescription="Nike Desc";
    };  
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BrandAddComponent],
            imports: [RouterTestingModule,HttpClientModule,ReactiveFormsModule],
            providers: [BrandService]
        }).compileComponents();
    }));
    beforeEach(()=>{
        fixture = TestBed.createComponent(BrandAddComponent);
        component = fixture.componentInstance;
    })
    it('should create', async(() => {     
        expect(component).toBeTruthy();
    }));
    // it('Add New Brand',async(inject([BrandService],(brandServie)=>{
    //      brandServie.addNewBrand(brand).subscribe(result=>{         
    //         console.log("Brand Added successfully");          
    //       })  
    //  })));
})
