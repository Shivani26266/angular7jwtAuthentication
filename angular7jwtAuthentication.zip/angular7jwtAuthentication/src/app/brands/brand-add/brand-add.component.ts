import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BrandService } from 'src/app/_services/brand.service';
import { Brand } from 'src/app/_models/brand';

@Component({
  selector: 'app-brand-add',
  templateUrl: './brand-add.component.html',
  styleUrls: ['./brand-add.component.css'],
  providers:[BrandService]
})
export class BrandAddComponent implements OnInit {
  
  brand:Brand=new Brand();
  brandForm: FormGroup;
  constructor(private _br:BrandService,private router:Router,private fb:FormBuilder) { 
    this.createForm();
  }

  ngOnInit() {
  }
  addNewBrand(){
    this._br.addNewBrand(this.brand).subscribe(result =>{
      console.log(result);
      console.log('Brand Added Successfully.');
      this.router.navigate(['/brand']);
    });
  }
   
  createForm(){
    this.brandForm=this.fb.group({
      brandName:['',Validators.required],
      brandDescription:['',Validators.required]
    })
  }
}