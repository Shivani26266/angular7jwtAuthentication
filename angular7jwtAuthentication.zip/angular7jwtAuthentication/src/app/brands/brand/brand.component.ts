import { Component, OnInit } from '@angular/core';
import { BrandService } from 'src/app/_services/brand.service';
import { Brand } from 'src/app/_models/brand';

@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.css'],
  providers: [BrandService]
})
export class BrandComponent implements OnInit {

  brands: Brand[];
  constructor(private _brands: BrandService) { }

  ngOnInit() {
    this.getAllBrands()
  }
  getAllBrands() {
    this._brands.getBrands().subscribe(result => {
      this.brands = result;
      console.log(this.brands);
    })
  }
  deleteExistingBrand(id: number) {
    this._brands.deleteBrands(id).subscribe(result => {
      console.log("Brand Deleted Successfully");
      this.getAllBrands();

    })
  }
}
